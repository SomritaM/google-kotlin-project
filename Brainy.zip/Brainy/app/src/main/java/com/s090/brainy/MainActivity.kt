package com.s090.brainy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {



    fun starter(view: View)
    {
        view.visibility = View.INVISIBLE
        timerView.visibility = View.VISIBLE
        Toast.makeText(applicationContext, "App started", Toast.LENGTH_LONG).show()
        val timer = object: CountDownTimer(30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerView.setText("Time: "+(millisUntilFinished/1000))
            }

            override fun onFinish() {
                timerView.setText("Timer Over.")
            }
        }
        timer.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        start.visibility=View.VISIBLE
        timerView.visibility = View.INVISIBLE
    }


}
